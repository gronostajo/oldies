jquery.trimpath
===============

jQuery plugin for trimming file paths the intelligent way.