(function($) {

	$.fn.trimpath = function(args) {

		args = $.extend({
			'width': 0,
			'ellipsis': '...'
		}, args);

		this.each(function() {

			var e = $(this);

			var width = args.width;

			if (!width)
				width = e.filter('[data-width]').length ? parseInt(e.attr('data-width')) : e.parent().width();

			e.css({
				'display': 'inline-block',
				'overflow': 'visible',
				'width': 'auto',
				'white-space': 'nowrap'
			});

			if (e.width() > width) {

				var path = e.text().split('\\');
				var drive = path.shift() + '\\';
				var ext = path.pop();
				path.push(ext.substr(0, ext.lastIndexOf('.')));
				ext = ext.substr(ext.lastIndexOf('.'));

				if (path.length == 2)
					path.unshift(path.pop());
				else if (path.length >= 3) {
					var tmp = path.pop();
					path.unshift(path.pop());
					path.unshift(tmp);
				}

				path = path.join('\\');

				e.text(drive + path + args.ellipsis + ext);
				while (e.width() > width && path.length) {
					path = path.substr(0, path.length - 1);
					e.text(drive + path + args.ellipsis + ext);
				}

				path += args.ellipsis;

				path = path.split('\\');
				if (path.length == 2)
					path.push(path.shift());
				else if (path.length >= 3) {
					var tmp = path.shift();
					path.push(path.shift());
					path.push(tmp);
				}

				e.text(drive + path.join('\\') + ext);

			}

			e.css({
				'display': 'block',
				'width': width + 'px'
			});

		});

		return this;

	};

})(jQuery);