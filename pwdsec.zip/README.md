[pwdsec](https://gronostajo.github.io/pwdsec/)
======

Krótki crash test bezpieczeństwa haseł... i niebezpieczeństwa ludzi.

*Projekt jest mocno zakurzony technicznie, ale wciąż aktualny treściowo :)*
