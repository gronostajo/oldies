// (C) 2012 Krzysztof Śmiałek
// http://avensome.net/

$(function() {
	// Javascript required
	$('.nojs').removeClass('nojs');
	$('#nojs').remove();
	// mark screens
	$('#wrapper > div').addClass('screen').each(function() {
		$(this).attr('id', 'screen' + $(this).index());
	}).first().addClass('screen-current').css('display', 'block');
	// add anchors
	$('.screen').each(function() {
		$(this).prepend('<a name="' + $(this).attr('id') + '" />');
	});
	// navigation
	$('nav').hide();
	$(window).bind('hashchange', function() {
		var hash = (window.location.hash == '') ? 'screen0' : window.location.hash.substr(1);
		if (($('.screen-current').attr('id') != hash)) {
			$('.screen-current').removeClass('screen-current').slideUp();
			$('#' + hash).addClass('screen-current').slideDown();
			if ($('.screen-current').attr('id') == 'screen0')
				$('nav').slideUp();
			else if (!$('nav:visible').length)
				$('nav').slideDown();
			if ($('.screen-current').next().length)
				$('#next').fadeIn();
			else
				$('#next').fadeOut();
			if ($('.screen-current').hasClass('dark'))
				$('body').addClass('dark');
			else
				$('body').removeClass('dark');
			$('html, body').animate({'scrollTop': 0});
		}
	});
	// next/previous
	$('#prev').click(function (event) {
		event.preventDefault();
		if ($('.screen-current').prev().length)
			window.location.hash = $('.screen-current').prev().attr('id');
	})
	$('#next').click(function (event) {
		event.preventDefault();
		if ($('.screen-current').next().length)
			window.location.hash = $('.screen-current').next().attr('id');
	})
	// don't be evil!
	var gotcha = function (event) {
		event.preventDefault();
		if ($('.screen-current').attr('id') == 'screen0') {
			window.location.hash = 'screen1';
			$('body').addClass('dark');
			$('#honeypot').attr('value', '');
		}
	};
	$('#honeypot').keyup(gotcha).change(gotcha).submit(gotcha);

	/* --- UNCOMMENT WHEN EDITING - ENABLES LABELS ON REFRESH --- */
	/*
	if (window.location.hash != '') {
		$('.screen-current').removeClass('screen-current').hide();
		$(window.location.hash).addClass('screen-current').show();
		if ($('.screen-current').attr('id') == 'screen0')
			$('nav').hide();
		else if (!$('nav:visible').length)
			$('nav').show();
		if (!$('.screen-current').next().length)
			$('#next').hide();
		if ($('.screen-current').hasClass('dark'))
			$('body').addClass('dark');
		else
			$('body').removeClass('dark');
	}
	/* --- COMMENT AFTER EDITING --- */
	if (window.location.hash != '')
		window.location.hash = '';


	// slidebuttons
	$('.slidebtn').click(function (event) {
		event.preventDefault();
		$(this).animate({'opacity': 0, 'height': 0, 'margin-top': 0, 'margin-bottom': 0}).next().slideDown();
	})
	// honesty proof
	$('.proof').hover(function() {
		var pos = $(this).position().top - $('#proof').outerHeight();
		$('#proof').fadeIn().css({'top': pos});
	}, function() {
		$('#proof').fadeOut();
	}).click(function (event) {
		event.preventDefault();
	});
	// trees
	$('.tree a').each(function() {
		if ($(this).next().get(0) && (($(this).next().get(0).tagName == 'UL') || ($(this).next().get(0).tagName == 'OL')))
			$(this).click(function (event) {
				event.preventDefault();
				if ($(this).parent().hasClass('expanded')) {
					$(this).parent().removeClass('expanded').children('ul, ol').slideUp();
				}
				else {
					$(this).parent().addClass('expanded').children('ul, ol').slideDown();
				}
			});
	});
	// floater
	function loadFloater(selector) {
		$('#floater > div > div').html($(selector).html()).css('height', 'auto');
		$('#floater > div > div .floater').click(function (event) {
			event.preventDefault();
			loadFloater('#' + $(this).attr('data-id'));
		});
		$('#floater').fadeIn();
		$('#floater > div > div').css('height', $('#floater > div').height() + 1);
	}
	$(window).resize(function() {
		if ($('#floater:visible').length)
			$('#floater > div > div').css('height', 'auto').css('height', $('#floater > div').height() + 1);
	});
	$('#floater_x').click(function() {
		$('#floater').fadeOut(250);
	});
	$('.floater').click(function (event) {
		event.preventDefault();
		loadFloater('#' + $(this).attr('data-id'));
	});
	// mail protection
	$('span.automail').each(function() {
		var txt = $(this).html();
		var addr = $(this).attr('data-user') + '@' + $(this).attr('data-domain');
		$(this).html($('<a/>').attr('href', 'mailto:' + addr).html(txt));
	});
	// share
	$('#share').click(function (event) {
		event.preventDefault();
		var wnd = window.open('https://www.facebook.com/sharer.php?u=http://gronostajo.github.com/pwdsec/&t=Sprawd%C5%BA%20jak%20bezpieczne%20jest%20Twoje%20has%C5%82o!%0A', 'open', 'width=480,height=292');
		if (window.focus) wnd.focus();
	});
});
