yolo
====

Bądź bardziej #yolo na fejsuniu - bez żadnego wysiłku!

[Klik, klik: http://gronostajo.github.io/yolo/](http://gronostajo.github.io/yolo/)
