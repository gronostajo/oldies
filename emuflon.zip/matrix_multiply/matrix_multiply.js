function resizeFont() {
	var font = 2 * Math.round($(window).height() / 72);
	$('#main').css('fontSize', $('#scale:checked').length ? Math.max(font, 20) : 20 + 'px');
	$('#scale + label').css('display', $(window).height() >= 720 ? 'block' : 'none');
}

$(function() {

	var size = new Array(2, 2, 2);

	function setHover() {
		$('#matrix3 td').off('mouseenter mouseleave').hover(function() {
			var e = $(this);
			var x = e.index();
			var y = e.parent().index();
			elementFocus(e, x, y);
		}, function() {
			var e = $(this);
			var x = e.index();
			var y = e.parent().index();
			elementBlur(e, x, y);
		});
	}

	function numbersOnly() {
		$('.matrix').find('td').off('change').removeNumeric();
		$('.resizable').find('td').change(calculateMatrix)
		.numeric(false, function() {
			var e = $(this);
			e.text(parseInt(e.text()));
			if (e.text() == 'NaN')
				e.text('0');
			calculateMatrix();
		});
	}

	function deleteRow(tab) {
		tab.children('tbody').children('tr').last().remove();
		numbersOnly();
	}

	function deleteCol(tab) {
		tab.children('tbody').children('tr').children('td:last-child').remove();
		numbersOnly();
	}

	function insertRow(tab, edit) {
		tab = tab.children('tbody');
		var c = tab.children('tr').first().children('td').length;
		var row = $('<tr/>').addClass('row' + (tab.children('tr').length+1)).appendTo(tab);
		for (var i = 0; i < c; i++) {
			var td = $('<td/>').addClass('col' + (i+1)).text('0');
			edit ? td.attr('contenteditable', 'true') : 0;
			row.append(td);
		}
		setHover();
		numbersOnly();
	}

	function insertCol(tab, edit) {
		tab = tab.children('tbody');
		tab.children('tr').each(function() {
			var td = $('<td/>').addClass('col' + (tab.children('tr').last().children('td').length+1)).text('0');
			edit ? td.attr('contenteditable', 'true') : 0;
			$(this).append(td);
		});
		setHover();
		numbersOnly();
	}

	function getValue(mx, x, y) {
		var r = parseInt($(mx).children('table').children('tbody').children('tr').eq(y).children('td').eq(x).text());
		return r;
	}

	function calculateValue(x, y) {
		var e = $('#matrix3').children('table').children('tbody').children('tr').eq(y).first().children('td').eq(x);
		var r = 0;
		for (var i = 0; i < size[1]; i++)
			r += getValue('#matrix1', i, y) * getValue('#matrix2', x, i);
		e.text(r);
		return r;
	}

	function calculateMatrix() {
		for (var y = 0; y < $('#matrix3').children('table').children('tbody').children('tr').length; y++)
			for (var x = 0; x < $('#matrix3').children('table').children('tbody').children('tr').first().children('td').length; x++)
				calculateValue(x, y);
	}

	function elementFocus(e, x, y) {
		$('#matrix1 tr').eq(y).addClass('highlight');
		$('#matrix2 td').each(function() {
			var e = $(this);
			if (e.index() == x)
				e.addClass('highlight');
		});
		var code = new Array();
		for (var i = 0; i < size[1]; i++) {
			var e = $('<div/>');
			$('<span/>').addClass('elem elem' + (i+1)).text(getValue('#matrix1', i, y)).appendTo(e);
			h = e.html() + '&times;';
			e.children().remove();
			$('<span/>').addClass('elem elem' + (i+1)).text(getValue('#matrix2', x, i)).appendTo(e);
			h += e.html();
			code.push(h);
		}
		code = '<span class="group">' + code.join('</span><span class="plus">+</span><span class="group">') + '</span><span class="plus">=</span><span class="elem result">' + calculateValue(x, y) + '</span>';
		$('<div id="solution" class="solution" />').hide().appendTo('#main').html(code).slideDown(200);
	}

	function elementBlur(e, x, y) {
		$('#matrix1 tr.highlight').removeClass('highlight');
		$('#matrix2 td.highlight').removeClass('highlight');
		$('#solution').removeAttr('id').addClass('tbr').delay(100).slideUp(200);
		setTimeout(function() {
			$('.tbr').first().remove();
		}, 300);
	}

	function resizeMatrix() {
		var vals = size.slice();
		var e = $('#sidebar .sidespin-mid');
		for (var i = 0; i < 3; i++)
			vals[i] = parseInt(e.eq(i).text());
		console.log('bump');
		console.log(size);
		console.log(vals);

		if (vals[0] > size[0]) {
			size[0] = vals[0];
			insertRow($('#matrix1 table'), true);
			insertRow($('#matrix3 table'), false);
		}
		else if (vals[0] < size[0]) {
			size[0] = vals[0];
			deleteRow($('#matrix1 table'));
			deleteRow($('#matrix3 table'));
		}

		if (vals[1] > size[1]) {
			size[1] = vals[1];
			insertCol($('#matrix1 table'), true);
			insertRow($('#matrix2 table'), true);
		}
		else if (vals[1] < size[1]) {
			size[1] = vals[1];
			deleteCol($('#matrix1 table'));
			deleteRow($('#matrix2 table'));
		}

		if (vals[2] > size[2]) {
			size[2] = vals[2];
			insertCol($('#matrix2 table'), true);
			insertCol($('#matrix3 table'), false);
		}
		else if (vals[2] < size[2]) {
			size[2] = vals[2];
			deleteCol($('#matrix2 table'));
			deleteCol($('#matrix3 table'));
		}
	}

	$('.sidespin').each(function() {
		var e = $(this);
		var min = parseInt(e.attr('data-min'));
		var max = parseInt(e.attr('data-max'));
		var text = e.text();
		e.text('').on('mousedown selectstart', function(e) { e.preventDefault(); });
		$('<div class="sidespin-left" />').html('&#45;').appendTo(e).click(function() {
			var v = parseInt(e.children('.sidespin-mid').text());
			if (v-1 >= min) {
				e.children('.sidespin-mid').text(v-1);
				resizeMatrix();
			}
		});
		$('<div class="sidespin-mid" />').text(text).appendTo(e);
		$('<div class="sidespin-right" />').html('&#43;').appendTo(e).click(function() {
			var v = parseInt(e.children('.sidespin-mid').text());
			if (v+1 <= max) {
				e.children('.sidespin-mid').text(v+1);
				resizeMatrix();
			}
		});
		$('<div class="clear" />').html('&nbsp;').appendTo(e);
	});

	$('.matrix').each(function() {
		var e = $(this);
		var edit = e.hasClass('resizable');
		var tab = $('<table/>').appendTo(e).append($('<tr/>').addClass('row1').append($('<td/>').addClass('col1').text('0')));
		edit ? tab.find('td').attr('contenteditable', 'true') : 0;
		insertRow(tab, edit);
		insertCol(tab, edit);
		setHover();
	});

	$('#randomize').click(function() {
		$('.resizable').find('td').each(function() {
			var x = Math.floor(Math.random() * 9 - 4);
			$(this).text(x);
		});
		calculateMatrix();
	});

	$('#scale + label').on('mousedown selectstart', function(e) { e.preventDefault(); });
	$('#scale').change(resizeFont);

});

$(window).resize(resizeFont);
